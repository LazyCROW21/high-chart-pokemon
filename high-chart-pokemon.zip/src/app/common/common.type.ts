export type Option = {
    label: string;
    value: any;
}